package com.example.a3p97_calc;

import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import org.mozilla.javascript.Context;
import org.mozilla.javascript.Scriptable;

import java.util.Arrays;
import java.util.regex.*;


public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    TextView output, values; // Calculator visualization
    Button buttonAC, buttonMS, buttonMR, buttonDivide, buttonMultiply, buttonSubtract, buttonPlus, buttonEquals, button0, button1, button2, button3, button4, button5, button6, button7, button8, button9, buttonDot, buttonBack; //
    // Buttons
    String store = "0"; // Value for memory
    // Memory storage
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        //Assign UI ids to variables
        output = findViewById(R.id.output);
        values = findViewById(R.id.values);

        matchId(buttonAC, R.id.button_ac);
        matchId(buttonMS, R.id.button_MS);
        matchId(buttonMR, R.id.button_MR);
        matchId(buttonDivide, R.id.button_divide);
        matchId(buttonMultiply, R.id.button_multiply);
        matchId(buttonSubtract, R.id.button_subtract);
        matchId(buttonPlus, R.id.button_plus);
        matchId(buttonEquals, R.id.button_equals);
        matchId(button0, R.id.button_0);
        matchId(button1, R.id.button_1);
        matchId(button2, R.id.button_2);
        matchId(button3, R.id.button_3);
        matchId(button4, R.id.button_4);
        matchId(button5, R.id.button_5);
        matchId(button6, R.id.button_6);
        matchId(button7, R.id.button_7);
        matchId(button8, R.id.button_8);
        matchId(button9, R.id.button_9);
        matchId(buttonDot, R.id.button_dot);
        matchId(buttonBack, R.id.button_back);

    }

    // Swap between portrait and landscape mode
    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);

        // Checks the orientation of the screen
        if (newConfig.orientation == Configuration.ORIENTATION_LANDSCAPE) {
            Toast.makeText(this, "landscape", Toast.LENGTH_SHORT).show();
        } else if (newConfig.orientation == Configuration.ORIENTATION_PORTRAIT) {
            Toast.makeText(this, "portrait", Toast.LENGTH_SHORT).show();
        }
    }

    // UI matching for buttons only
    void matchId(Button b, int id){

        b = findViewById(id);
        b.setOnClickListener(this);

    }


    // Interaction with UI
    @Override
    public void onClick(View view) {

        Button b = (Button) view; // Clicked button
        String bText = b.getText().toString(); // Value of button clicked
        String data = values.getText().toString(); // String representing current equation

        // Invalid calculation (divide-by-zero)
        if (output.getText().toString().contains("Error")){

            cError();
            return;

        }

        // Clear all values
        if (bText.equals("AC")){

            cAC();
            return;

        }

        // Perform calculation early
        if (bText.equals("=")){

            cEquals();
            return;

        }

        // Clear last entered digit/operator

        if (bText.equals("C")) {

            cC();
            return;

        }

        // Store current value in memory
        if (bText.equals("MS")){

            cMS();
            return;

        }


        // Auto-calculate after two operators
        if (bText.equals("+") || bText.equals("-") || bText.equals("*") || bText.equals("/")){

            String regex = "[+*\\/-]"; // Valid operators
            Pattern p = Pattern.compile(regex);
            Matcher m = p.matcher(data);

            if (m.find()){ // One operator exists, therefore new value is second

                values.setText(output.getText() + bText);
                return;

            }


        }

        // Decimal input
        if (bText.equals(".")){

            cDot(bText);
            return;

        }

        // Add stored value into equation
        if (bText.equals("MR")){

            data += store;


        } else {

            data += bText;

        }

        // General input handling for other buttons
        values.setText(data);

        String res = calculate(data);

        if (res.equals("Infinity")){

            res = "Error";

        }

        if (!res.equals("fail")){

            output.setText(res);

        }

    }

    // Reset to 0 on error
    void cError(){

        values.setText("0");
        output.setText("0");


    }

    // Clear all text
    void cAC(){

        values.setText("");
        output.setText("0");

    }

    // Calculate values early
    void cEquals(){

        if (!output.getText().equals("0")){

            values.setText(output.getText());

        }

    }

    // Clear each digit, ignore 0 and act as AC on 1
    void cC(){

        if (values.getText().toString().length() == 0) {


        } else if (values.getText().toString().length() == 1) {

            values.setText("");
            output.setText("0");


        } else {

            values.setText(values.getText().toString().substring(0, values.getText().toString().length() - 1));

        }


    }

    // Store current value, default 0
    void cMS(){

        store = output.getText().toString();

        if (store.endsWith(".0")){

            store = store.replace(".0", "");

        }

    }

    // Add decimal, only once per operand
    void cDot(String bText){

        String regex = "[.]";
        Pattern p = Pattern.compile(regex);
        String[] datatemp = values.getText().toString().split("[+*\\/-]"); // Get individual operands

        Matcher n = p.matcher(datatemp[datatemp.length - 1]); // Last operand has invalid deimals

        if (n.find()){

            values.setText(output.getText());

        } else {

            values.setText(values.getText() + bText);
        }


    }


    // General input calculations for buttons not already handled
    String calculate(String data){

        try {

            Context c = Context.enter();
            c.setOptimizationLevel(-1);
            Scriptable s = c.initStandardObjects();
            String res = c.evaluateString(s, data, "", 1, null).toString();

          if (res.endsWith(".0")){

              res = res.replace(".0", "");

          }

          return res;

        } catch (Exception e) {

            return "fail";

        }

    }

}